

<img align="left" src="https://user-images.githubusercontent.com/65187002/144930161-2f783401-8d27-4fdf-a2f7-cc0ba32f1f1f.gif" width="21%" style="display:inline;"><img align="right" src="https://user-images.githubusercontent.com/65187002/144930161-2f783401-8d27-4fdf-a2f7-cc0ba32f1f1f.gif" width="21%" style="display:inline;">

<h1 align="center">Hi 👋, I'm 𝗪𝗔𝗧𝗦𝗢𝗡𝗫𝗗</h1>
<h3 align="center">A passionate Developer from WATSON-TECH</h3>

<p align="center">I'm fascinated by how technology is shaping the world and always strive to create impactful projects. I'm passionate about learning new tech stacks and building solutions that blend creativity and functionality.</p>
<p align="center"> 
 <img src="https://komarev.com/ghpvc/?username=supuna97&label=Profile%20views&color=0e75b6&style=flat" alt="supun nanayakkara" /> 
<!--  <img src="https://img.shields.io/badge/Languages-Python | Java | PHP | Typescript | Node | React -green.svg" alt="supun nanayakkara's languages" /> -->
<!--  <img alt="Profile followers" src="https://img.shields.io/github/followers/supuna97"> -->
</p>

<div align="center">
  <img src="https://techstack-generator.vercel.app/java-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/python-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/ts-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/js-icon.svg" alt="icon"width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/react-icon.svg" alt="icon" width="50" height="50" />
 <img src="https://techstack-generator.vercel.app/mysql-icon.svg" alt="icon" width="50" height="50" />
</div>

<br>

<div align="center">
  <img src="https://techstack-generator.vercel.app/docker-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/aws-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/github-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/prettier-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/restapi-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/graphql-icon.svg" alt="icon" width="50" height="50" />
</div>

<img align="right" alt="Coding" width="400" src="https://user-images.githubusercontent.com/74038190/229223263-cf2e4b07-2615-4f87-9c38-e37600f8381a.gif">
<br><br>

- 🔭 I’m currently working on **𝗪𝗔𝗧𝗦𝗢𝗡𝗫𝗗-TECH Projects**

- 🌱 I’m currently learning **JAVASCRIPT**

- 👨‍💻 All of my projects are available at [WATSONXD GitHub](https://github.com/watsonxdboy)

- 📫 How to reach me: **fourpencewatson7@gmail.com**

- ⚡ Fun fact: **I think code is the ultimate form of creativity**

<br>

<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://www.youtube.com/@WATSON-TECH" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/youtube.svg" alt="YouTube" height="30" width="40" /></a>
<a href="https://whatsapp.com/channel/0029VajjzuB9sBI890YffB1b" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/whatsapp.svg" alt="WhatsApp" height="30" width="40" /></a>
</p>

<img align="right" alt="Coding<img align="right" alt="Coding" width="400" src="https://files.catbox.moe/rfowi7.jpg">"

<h3 align="left">Languages and Tools:</h3>

- **Backend**
<p align="left">
  <a href="https://skillicons.dev">
    <img src="https://skillicons.dev/icons?i=php,java,nodejs,py" />
  </a>
</p>

- **Frontend**
<p align="left">
  <a href="https://skillicons.dev">
    <img src="https://skillicons.dev/icons?i=ts,js,react,tailwind" />
  </a>
</p>

- **Database**
<p align="left">
  <a href="https://skillicons.dev">
    <img src="https://skillicons.dev/icons?i=mongodb,mysql" />
  </a>
</p>

<br/>

<h3 align="left">GitHub Stats:</h3>
<div align="center">

![WATSON-XD GitHub stats](https://github-readme-stats.vercel.app/api?username=watsonxdboy&theme=midnight-purple&show_icons=true)

[![GitHub Streak](https://streak-stats.demolab.com/?user=watsonxdboy&theme=midnight-purple)](https://git.io/streak-stats)

</div>

<br><br>

<img src="https://i.imgur.com/dBaSKWF.gif" height="20" width="100%">
